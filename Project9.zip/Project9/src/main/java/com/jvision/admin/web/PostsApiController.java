package com.jvision.admin.web;


import com.jvision.admin.service.posts.PostsService;
import com.jvision.admin.web.dto.PostsResponseDto;
import com.jvision.admin.web.dto.PostsSaveRequestDTO;
import com.jvision.admin.web.dto.PostsUpdateRequestDto;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RequiredArgsConstructor
@RestController
public class PostsApiController {

    private final PostsService postsService;

    //글 등록 HTTP 요청 (insert)
    @PostMapping("/api/v1/posts") //데이터전달방식 -> Get(보안수준 낮음), Post(보안 수준 높음)
    public long save(@RequestBody PostsSaveRequestDTO requestDto)
    {
        return postsService.save(requestDto);
    }

    //아이디 조회(클릭) -> 글 수정 HTTP 요청 (update)
    @PutMapping("/api/v1/posts/{id}")
    public Long update(@PathVariable Long id, @RequestBody PostsUpdateRequestDto requestDto){
        return postsService.update(id, requestDto);
    }

    //아이디 조회(클릭) -> 글 조회 HTTP 요청 (select)
    @GetMapping("/api/v1/posts/{id}")
    public PostsResponseDto findById(@PathVariable Long id)
    {
        return postsService.findById(id);
    }

    @DeleteMapping("api/v1/posts/{id}")
    public Long delete(@PathVariable Long id)
    {
        postsService.delete(id);
        return id;
    }
}
