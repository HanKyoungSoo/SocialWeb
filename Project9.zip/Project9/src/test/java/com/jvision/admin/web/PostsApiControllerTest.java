package com.jvision.admin.web;


import com.jvision.admin.domain.posts.Posts;
import com.jvision.admin.domain.posts.PostsRepository;
import com.jvision.admin.web.dto.PostsSaveRequestDTO;
import com.jvision.admin.web.dto.PostsUpdateRequestDto;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)// WebMvcTest --> JAP가 동작되지 않음, SpringBootTest/TestRestTemplate


public class PostsApiControllerTest {

    @Autowired
    private TestRestTemplate testRestTemplate;

    @LocalServerPort
    private int port;

    @Autowired
    private PostsRepository postsRepository;

    @After
    public void tearDown() throws Exception{

        postsRepository.deleteAll();
    }

    @Test
    public void Posts_등록된다() throws Exception
    {
        //Posts 멤버변수에 저장될 사용자 입력 값!!
        String title = "title";
        String content = "content";
        String author = "author";


        //사용자 요청 객체 requestDto 생성
        PostsSaveRequestDTO requestDto = PostsSaveRequestDTO.builder()
                .title(title)
                .content(content)
                .author(author)
                .build();

        //웹 브라우저를 통해 requestDto 객체를 헤더와 함께 전송할 uri(사용자 요청 경로)
        String url = "http://localhost:" + port + "/api/v1/posts";

        ResponseEntity<Long> responseEntity = testRestTemplate.postForEntity(url, requestDto, Long.class);
        //검증(HTTP 전송 규약을 통해 메시지 전송 OK)
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK); //HTTP 전송 OK?
        assertThat(responseEntity.getBody()).isGreaterThan(0L); // requestDto가 메시지 Body에 저장된것인지? 확인
        //검증(데이터 베이스로부터 전체 레코드 검색 후 첫번째 레코드의 타이틀, 내용, 저자 비교)
        List<Posts> all = postsRepository.findAll();
        assertThat(all.get(0).getTitle()).isEqualTo(title);
        assertThat(all.get(0).getContent()).isEqualTo(content);
        assertThat(all.get(0).getAuthor()).isEqualTo(author);

    }

    @Test
    public void Posts_수정된다() throws Exception
    {
        Posts savedPosts = postsRepository.save(Posts.builder()
                .title("title")
                .content("content")
                .author("author")
                .build());

        Long updateId = savedPosts.getId();
        String expectedTitle = "title2";
        String expectedContent = "content2";


        //사용자 요청 객체 requestDto 생성
        PostsUpdateRequestDto requestDto = PostsUpdateRequestDto.builder()
                .title(expectedTitle)
                .content(expectedContent)
                .build();

        //웹 브라우저를 통해 requestDto 객체를 헤더와 함께 전송할 uri(사용자 요청 경로)
        String url = "http://localhost:" + port + "/api/v1/posts/" + updateId;

        HttpEntity<PostsUpdateRequestDto> requestEntity = new HttpEntity<>(requestDto);

        ResponseEntity<Long> responseEntity = testRestTemplate.exchange(url, HttpMethod.PUT, requestEntity, Long.class);

        //검증(HTTP 전송 규약을 통해 메시지 전송 OK)
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK); //HTTP 전송 OK?
        assertThat(responseEntity.getBody()).isGreaterThan(0L); // requestDto가 메시지 Body에 저장된것인지? 확인
        //검증(데이터 베이스로부터 전체 레코드 검색 후 첫번째 레코드의 타이틀, 내용, 저자 비교)

        List<Posts> all = postsRepository.findAll();
        assertThat(all.get(0).getTitle()).isEqualTo(expectedTitle);
        assertThat(all.get(0).getContent()).isEqualTo(expectedContent);


    }

}


















